/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challenge.pkg5;

import java.util.Scanner;

/**
 * Challenge#5_6281318
 *COP3804 U04X 1221 Due date:3/23/2022
 */
public class Challenge5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner keyboard = new Scanner(System.in);
        Challenge5 object = new Challenge5();
        String again = "y";
        
         
        while(again.equalsIgnoreCase("y")){ //loop that repeats as long as string again is y
            System.out.println("input the string you wish to convert: "); //asks user for string
            String input = keyboard.nextLine(); //takes user input and gives it to string input
            System.out.println(object.changeXY(input)); //calls and prints reults from the changeXY method
            System.out.println("Do you have another string to input? (y for yes or any other key for no)"); //asks user if they want to submit another string
            again = keyboard.nextLine(); //takes input from user and gives to string again
        }       
    }
    
    public String changeXY(String str) {
       if (str.equals("")) //checks if string is empty then returns the string
           return str;
       if (str.charAt(0) == 'x') // checks if character at index is x then appends x to remaining characters
           return "y" + changeXY(str.substring(1));      
       return str.charAt(0) + changeXY(str.substring(1));
       }
    
}
